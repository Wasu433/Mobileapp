from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from typing import List

# 📌 Import function CRUD
from product import (
    get_all_food, create_food, update_food, delete_food,
    get_all_memo, create_memo, update_memo, delete_memo,
    get_all_math, create_math, update_math, delete_math
)

# 📌 Import models
from product.models import ThaifoodModel, MemoModel, MathModel

app = FastAPI()

# ==================================
# 🌐 CORS Middleware
# ==================================
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==================================
# 🏠 Root endpoint
# ==================================
@app.get("/")
async def root():
    return {"message": "Hello CPSU!"}


# ==================================
# 🍜 CRUD: THAIFOOD
# ==================================
@app.get("/thaifood", response_model=List[ThaifoodModel])
async def read_food():
    return get_all_food()


@app.post("/thaifood", response_model=ThaifoodModel, status_code=status.HTTP_201_CREATED)
async def create_new_food(food: ThaifoodModel):
    new_id = create_food(food)
    return {**food.dict(), "id": new_id}


@app.put("/thaifood/{food_id}", response_model=ThaifoodModel)
async def update_food_item(food_id: int, food: ThaifoodModel):
    rows = update_food(food_id, food)
    if rows == 0:
        raise HTTPException(status_code=404, detail="Food not found")
    return {**food.dict(), "id": food_id}


@app.delete("/thaifood/{food_id}")
async def delete_existing_food(food_id: int):
    delete_food(food_id)
    return {"message": "Food deleted successfully"}


# ==================================
# 📝 CRUD: MEMO
# ==================================
@app.get("/memo", response_model=List[MemoModel])
async def read_memo():
    return get_all_memo()


@app.post("/memo", response_model=MemoModel, status_code=status.HTTP_201_CREATED)
async def create_new_memo(memo: MemoModel):
    new_id = create_memo(memo)
    return {**memo.dict(), "id": new_id}


@app.put("/memo/{memo_id}", response_model=MemoModel)
async def update_memo_item(memo_id: int, memo: MemoModel):
    rows = update_memo(memo_id, memo)
    if rows == 0:
        raise HTTPException(status_code=404, detail="Memo not found")
    return {**memo.dict(), "id": memo_id}


@app.delete("/memo/{memo_id}")
async def delete_existing_memo(memo_id: int):
    delete_memo(memo_id)
    return {"message": "Memo deleted successfully"}


# ==================================
# 🧮 CRUD: MATH
# ==================================
@app.get("/math", response_model=List[MathModel])
async def read_math():
    return get_all_math()


@app.post("/math", response_model=MathModel, status_code=status.HTTP_201_CREATED)
async def create_new_math(item: MathModel):
    new_id = create_math(item)
    return {**item.dict(), "id": new_id}


@app.put("/math/{math_id}", response_model=MathModel)
async def update_math_item(math_id: int, item: MathModel):
    rows = update_math(math_id, item)
    if rows == 0:
        raise HTTPException(status_code=404, detail="Math item not found")
    return {**item.dict(), "id": math_id}


@app.delete("/math/{math_id}")
async def delete_existing_math(math_id: int):
    delete_math(math_id)
    return {"message": "Math item deleted successfully"}

