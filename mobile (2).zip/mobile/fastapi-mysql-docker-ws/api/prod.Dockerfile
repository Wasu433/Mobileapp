FROM python:3.9

WORKDIR /app

# Update the ENV information to the correct your production MySQL infos.
ENV APP_SECRET_STRING=P@ssW0rd
ENV DATABASE_USERNAME=user
ENV DATABASE_PASSWORD=P@ssW0rd
ENV DATABASE=fastapi_app
ENV DATABASE_HOST=127.0.0.1
ENV DATABASE_SOCKET=3306

RUN pip install --upgrade pip
COPY . .
RUN pip install --no-cache-dir -r  requirements.txt

ENV PORT 8080
ENV RAPTOR_MINI_ENABLED=true
EXPOSE 8080

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8080"]
# FROM python:3.9

# WORKDIR /app

# # ✅ Environment สำหรับเชื่อม MySQL ใน Docker Compose
# ENV APP_SECRET_STRING=P@ssW0rd
# ENV DATABASE_USERNAME=user
# ENV DATABASE_PASSWORD=P@ssW0rd
# ENV DATABASE=fastapi_app
# ENV DATABASE_HOST=mysql     
# ENV DATABASE_SOCKET=3306

# RUN pip install --upgrade pip
# COPY . .
# RUN pip install --no-cache-dir -r requirements.txt

# # ✅ ให้พอร์ตตรงกับ docker-compose
# ENV PORT 8000
# EXPOSE 8000

# # ✅ เปิดให้เข้าถึงจากภายนอก container
# CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
