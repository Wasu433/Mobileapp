from pydantic import BaseModel, field_validator
from typing import Optional
from datetime import date, time, datetime, timedelta

# ---------------------------- HR MODEL ----------------------------
class HrModel(BaseModel):
    id: Optional[int] = None
    firstname: str
    lastname: str
    gmail: str
    password: str
    department: str
    checkin_time: datetime
    checkout_time: Optional[datetime] = None
    work_date: date
    status: str = "on_time"
    ot_hours: float = 0.0

    @field_validator("checkin_time", "checkout_time", mode="before")
    def convert_datetime(cls, v):
        if v is None:
            return None
        if isinstance(v, str):
            return datetime.strptime(v, "%Y-%m-%d %H:%M:%S")
        return v


# ---------------------------- EMPLOYEE MODEL ----------------------------
class EmployeeModel(BaseModel):
    id: int
    firstname: str
    lastname: str
    gmail: str
    password: str
    department: str
    checkin_time: time
    checkout_time: Optional[time] = None
    work_date: date
    status: str = "on_time"
    ot_hours: float = 0.0

    @field_validator("checkin_time", "checkout_time", mode="before")
    def convert_time(cls, v):
        if v is None:
            return None

        if isinstance(v, timedelta):
            total_seconds = int(v.total_seconds())
            hours = (total_seconds // 3600) % 24
            minutes = (total_seconds % 3600) // 60
            seconds = total_seconds % 60
            return time(hour=hours, minute=minutes, second=seconds)

        if isinstance(v, str):
            return time.fromisoformat(v)

        return v


# ---------------------------- FOOD MODEL ----------------------------
class ThaifoodModel(BaseModel):
    id: Optional[int] = None
    foodname: str
    category: Optional[str] = None
    food_type: Optional[str] = None
    ingredients: Optional[str] = None
    instructions: Optional[str] = None


# ---------------------------- MEMO MODEL ----------------------------
class MemoModel(BaseModel):
    id: Optional[int] = None
    Title: str
    Note: Optional[str] = None


# ---------------------------- MATH MODEL ----------------------------
class MathModel(BaseModel):
    id: Optional[int] = None
    Title: str
    Amount: int = 0