from fastapi import HTTPException, APIRouter
from database.query import query_get, query_create, query_update
from typing import List, Optional
from pydantic import BaseModel

router = APIRouter()

# =======================
# Pydantic Models
# =======================
class ThaifoodModel(BaseModel):
    id: Optional[int] = None
    foodname: str
    category: Optional[str] = None
    food_type: Optional[str] = None
    ingredients: Optional[str] = None
    instructions: Optional[str] = None


class MemoModel(BaseModel):
    id: Optional[int] = None
    Title: str
    Note: Optional[str] = None


class MathModel(BaseModel):
    id: Optional[int] = None
    Title: str
    Amount: float


# ===============================
# CRUD: THAIFOOD
# ===============================
@router.get("/thaifood", response_model=List[ThaifoodModel])
def get_all_food():
    sql = """
        SELECT id, foodname, category, food_type, ingredients, instructions
        FROM thaifood
        ORDER BY id ASC
    """
    return query_get(sql, ())


@router.post("/thaifood", response_model=ThaifoodModel)
def create_food(food: ThaifoodModel):
    sql = """
        INSERT INTO thaifood (foodname, category, food_type, ingredients, instructions)
        VALUES (%s, %s, %s, %s, %s)
    """
    params = (food.foodname, food.category, food.food_type, food.ingredients, food.instructions)
    new_id = query_create(sql, params)

    return {**food.dict(), "id": new_id}


@router.put("/thaifood/{food_id}", response_model=ThaifoodModel)
def update_food(food_id: int, food: ThaifoodModel):
    sql = """
        UPDATE thaifood
        SET foodname=%s, category=%s, food_type=%s,
            ingredients=%s, instructions=%s
        WHERE id=%s
    """
    params = (food.foodname, food.category, food.food_type, food.ingredients, food.instructions, food_id)
    rows = query_update(sql, params)

    if rows == 0:
        raise HTTPException(status_code=404, detail="Food not found")

    return {**food.dict(), "id": food_id}


@router.delete("/thaifood/{food_id}")
def delete_food(food_id: int):
    sql = "DELETE FROM thaifood WHERE id=%s"
    rows = query_update(sql, (food_id,))

    if rows == 0:
        raise HTTPException(status_code=404, detail="Food not found")

    return {"message": "Food deleted successfully"}


# ===============================
# CRUD: MEMO
# ===============================
@router.get("/memo", response_model=List[MemoModel])
def get_all_memo():
    sql = "SELECT id, Title, Note FROM memo ORDER BY id ASC"
    return query_get(sql, ())


@router.post("/memo", response_model=MemoModel)
def create_memo(memo: MemoModel):
    sql = "INSERT INTO memo (Title, Note) VALUES (%s, %s)"
    new_id = query_create(sql, (memo.Title, memo.Note))
   


@router.put("/memo/{memo_id}", response_model=MemoModel)
def update_memo(memo_id: int, memo: MemoModel):
    sql = "UPDATE memo SET Title=%s, Note=%s WHERE id=%s"
    rows = query_update(sql, (memo.Title, memo.Note, memo_id))

    if rows == 0:
        raise HTTPException(status_code=404, detail="Memo not found")

    return {**memo.dict(), "id": memo_id}


@router.delete("/memo/{memo_id}")
def delete_memo(memo_id: int):
    sql = "DELETE FROM memo WHERE id=%s"
    rows = query_update(sql, (memo_id,))

    if rows == 0:
        raise HTTPException(status_code=404, detail="Memo not found")

    return {"message": "Memo deleted successfully"}


# ===============================
# CRUD: MATH
# ===============================
@router.get("/math", response_model=List[MathModel])
def get_all_math():
    sql = "SELECT id, Title, Amount FROM math ORDER BY id ASC"
    return query_get(sql, ())


@router.post("/math", response_model=MathModel)
def create_math(item: MathModel):
    sql = "INSERT INTO math (Title, Amount) VALUES (%s, %s)"
    new_id = query_create(sql, (item.Title, item.Amount))

   


@router.put("/math/{math_id}", response_model=MathModel)
def update_math(math_id: int, item: MathModel):
    sql = "UPDATE math SET Title=%s, Amount=%s WHERE id=%s"
    rows = query_update(sql, (item.Title, item.Amount, math_id))

    if rows == 0:
        raise HTTPException(status_code=404, detail="Math item not found")

    return {**item.dict(), "id": math_id}


@router.delete("/math/{math_id}")
def delete_math(math_id: int):
    sql = "DELETE FROM math WHERE id=%s"
    rows = query_update(sql, (math_id,))

    if rows == 0:
        raise HTTPException(status_code=404, detail="Math item not found")

    return {"message": "Math item deleted successfully"}
