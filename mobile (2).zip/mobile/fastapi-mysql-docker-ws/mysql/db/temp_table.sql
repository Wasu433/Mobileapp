
CREATE TABLE `hr` (
  `id` INT NOT NULL,
  `firstname` VARCHAR(256) NOT NULL,
  `lastname` VARCHAR(256) NOT NULL,
  `gmail` VARCHAR(256) NOT NULL,
  `password` VARCHAR(256) NOT NULL,
  `department` VARCHAR(256) NOT NULL,
  `checkin_time` DATETIME NOT NULL,
  `checkout_time` DATETIME DEFAULT NULL,
  `work_date` DATE NOT NULL,
  `status` ENUM('on_time', 'late', 'ot') DEFAULT 'on_time',
  `ot_hours` DECIMAL(4,2) DEFAULT 0,
  PRIMARY KEY (`id`)
);

INSERT INTO `hr` 
(`id`, `firstname`, `lastname`, `gmail`, `password`,`department`, `checkin_time`, `checkout_time`, `work_date`, `status`, `ot_hours`)
VALUES (11111, 'Warisaraporn', 'Kwanwipithakran ', 'wa@gmail.com', '25328','HR', '2025-09-01 08:25:00', '2025-09-01 17:00:00', '2025-09-01', 'on_time', 0.00);

INSERT INTO `hr` 
VALUES (22222, 'Napapat', 'Kanchita', 'nam@gmail.com', '11011','HR',  '2025-09-02 08:50:00', '2025-09-02 17:30:00', '2025-09-02', 'ot', 0.50);

CREATE TABLE employees (
  id INT,
  firstname VARCHAR(256) NOT NULL,
  lastname VARCHAR(256) NOT NULL,
  gmail VARCHAR(256) NOT NULL,
  password VARCHAR(256) NOT NULL,
  department VARCHAR(256) NOT NULL,
  checkin_time TIME NOT NULL,
  checkout_time TIME DEFAULT NULL,
  work_date DATE NOT NULL,
  status ENUM('on_time', 'late', 'ot', 'leave','absent') DEFAULT 'on_time',
  ot_hours DECIMAL(4,2) DEFAULT 0
);


CREATE TABLE thaifood (
  id INT NOT NULL AUTO_INCREMENT,
  foodname VARCHAR(256) NOT NULL,
  category VARCHAR(256),
  food_type VARCHAR(256),
  ingredients TEXT,
  instructions TEXT,
  PRIMARY KEY (id)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

INSERT INTO thaifood (foodname, category, food_type, ingredients, instructions)
VALUES (
  'ข้าวซอยไก่',
  'แกง',
  'ภาคเหนือ',
  'เส้นข้าวซอย, ไก่, กะทิ, พริกแกงข้าวซอย, หอมแดง, มะนาว',
  '1. ผัดพริกแกงกับกะทิให้หอม\n2. ใส่ไก่ลงไปผัดจนสุก\n3. เติมน้ำและเคี่ยวจนหอม\n4. ลวกเส้นและตักราด\n5. เสิร์ฟพร้อมเครื่องเคียง'
);

CREATE TABLE memo (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  Title VARCHAR(256) NOT NULL,
  Note TEXT     
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE math (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  Title VARCHAR(256) NOT NULL,
  Amount INT NOT NULL   
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

Insert INTO memo (Title, Note) VALUES
('Grocery List', 'Buy milk, eggs, and bread'),
('Meeting Notes', 'Discuss project timeline and deliverables'),
('Workout Plan', 'Monday: Cardio, Wednesday: Strength Training');

Insert INTO math (Title, Amount) VALUES
('Ipad', 35000);