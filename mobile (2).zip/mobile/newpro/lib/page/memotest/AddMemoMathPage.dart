import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AddMemoMathPage extends StatefulWidget {
  const AddMemoMathPage({super.key});

  @override
  State<AddMemoMathPage> createState() => _AddMemoMathPageState();
}

class _AddMemoMathPageState extends State<AddMemoMathPage> {
  final TextEditingController titleCtrl = TextEditingController();
  final TextEditingController amountCtrl = TextEditingController();

  String type = "income";

  String currentBackground = "";
  bool useNetwork = false;

  @override
  void initState() {
    super.initState();
    loadBackground();
  }

  Future<void> loadBackground() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      currentBackground = prefs.getString("bg_path") ?? "";
      useNetwork = prefs.getBool("bg_network") ?? false;
    });
  }

  Future<void> saveMath() async {
    try {
      print("📡 POST to server...");

      String formattedTitle =
          type == "income" ? "+${titleCtrl.text}" : "-${titleCtrl.text}";

      var response = await http.post(
        Uri.parse("http://localhost:8001/math"),
        headers: {"Content-Type": "application/json; charset=utf-8"},
        body: jsonEncode({
          "Title": formattedTitle,
          "Amount": int.tryParse(amountCtrl.text),
        }),
      );

      print("STATUS: ${response.statusCode}");

      if (response.statusCode == 200 || response.statusCode == 201) {
        Navigator.pop(context, true);
      } else {
        print("❌ Failed: ${response.statusCode}");
      }
    } catch (e) {
      print("❗ POST ERROR: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("เพิ่มรายรับ / รายจ่าย"),
        backgroundColor: Colors.green,
      ),

      body: Container(
        decoration: currentBackground.isEmpty
            ? const BoxDecoration(color: Colors.black)
            : BoxDecoration(
                image: DecorationImage(
                  image: useNetwork
                      ? NetworkImage(currentBackground)
                      : AssetImage(currentBackground) as ImageProvider,
                  fit: BoxFit.cover,
                ),
              ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(
                controller: titleCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: "ชื่อรายการ",
                  labelStyle: const TextStyle(color: Color.fromARGB(137, 0, 0, 0)),
                  filled: true,
                  fillColor: Colors.black.withOpacity(0.45),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),

              const SizedBox(height: 15),

              TextField(
                controller: amountCtrl,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Color.fromARGB(255, 255, 255, 255)),
                decoration: InputDecoration(
                  labelText: "จำนวนเงิน (บาท)",
                  labelStyle: const TextStyle(color: Color.fromARGB(137, 0, 0, 0)),
                  filled: true,
                  fillColor: Colors.black.withOpacity(0.45),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),

              const SizedBox(height: 18),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ChoiceChip(
                    label: const Text("รายรับ"),
                    labelStyle: const TextStyle(color: Colors.white),
                    selectedColor: Colors.green,
                    backgroundColor: Colors.grey.shade800,
                    selected: type == "income",
                    onSelected: (val) => setState(() => type = "income"),
                  ),
                  ChoiceChip(
                    label: const Text("รายจ่าย"),
                    labelStyle: const TextStyle(color: Colors.white),
                    selectedColor: Colors.red,
                    backgroundColor: Colors.grey.shade800,
                    selected: type == "expense",
                    onSelected: (val) => setState(() => type = "expense"),
                  ),
                ],
              ),

              const SizedBox(height: 25),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () async {
                    if (titleCtrl.text.isNotEmpty && amountCtrl.text.isNotEmpty) {
                      await saveMath();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text("บันทึก", style: TextStyle(fontSize: 18)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
