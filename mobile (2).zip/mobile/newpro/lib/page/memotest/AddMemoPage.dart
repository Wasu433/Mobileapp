import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AddMemoPage extends StatefulWidget {
  const AddMemoPage({super.key});

  @override
  State<AddMemoPage> createState() => _AddMemoPageState();
}

class _AddMemoPageState extends State<AddMemoPage> {
  final TextEditingController titleCtrl = TextEditingController();
  final TextEditingController contentCtrl = TextEditingController();

  String currentBackground = "";
  bool useNetwork = false;

  @override
  void initState() {
    super.initState();
    loadBackground();
  }

  Future<void> loadBackground() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      currentBackground = prefs.getString("bg_path") ?? "";
      useNetwork = prefs.getBool("bg_network") ?? false;
    });
  }

  Future<void> saveMemo() async {
    try {
      print("📡 Posting to server...");

      var response = await http.post(
        Uri.parse("http://localhost:8001/memo"),
        headers: {"Content-Type": "application/json; charset=utf-8"},
        body: jsonEncode({
          "Title": titleCtrl.text,
          "Note": contentCtrl.text,
        }),
      );

      print("STATUS: ${response.statusCode}");
      print("BODY: ${response.body}");

      if (response.statusCode == 201 || response.statusCode == 200) {
        Navigator.pop(context, jsonDecode(response.body));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("❌ บันทึกไม่สำเร็จ: ${response.statusCode}")),
        );
      }
    } catch (e) {
      print("❗ POST ERROR: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("เกิดข้อผิดพลาด: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("สร้าง Memo ใหม่"),
         backgroundColor: Colors.pink.withOpacity(0.85),
      ),


      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: currentBackground.isEmpty
                ? const AssetImage("assets/default.jpg") 
                : useNetwork
                    ? NetworkImage(currentBackground)
                    : AssetImage(currentBackground) as ImageProvider,
            fit: BoxFit.cover,
          ),
        ),

        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(
                controller: titleCtrl,
                style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0)),
                decoration: InputDecoration(

                  labelStyle: const TextStyle(color: Colors.white70),
                  filled: true,
                  fillColor: const Color.fromARGB(137, 220, 214, 214),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),

              const SizedBox(height: 15),

              TextField(
                controller: contentCtrl,
                maxLines: 10,
                style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0)),
                decoration: InputDecoration(
                  labelStyle: const TextStyle(color: Colors.white70),
                  filled: true,
                  fillColor: const Color.fromARGB(137, 220, 214, 214),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),

              const SizedBox(height: 25),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () async {
                    if (titleCtrl.text.isNotEmpty && contentCtrl.text.isNotEmpty) {
                      await saveMemo();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.pink.withOpacity(0.85),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text("บันทึก", style: TextStyle(fontSize: 18, color: Colors.black)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
