import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class MemoDetailPage extends StatefulWidget {
  final Map<String, dynamic> item;

  const MemoDetailPage({super.key, required this.item});

  @override
  State<MemoDetailPage> createState() => _MemoDetailPageState();
}

class _MemoDetailPageState extends State<MemoDetailPage> {
  String currentBackground = "assets/bg/bg1.jpg";  
  bool useNetwork = false;

  final TextEditingController noteCtrl = TextEditingController();
  final FocusNode focusNode = FocusNode();
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    loadBackground();
    noteCtrl.text = widget.item["Note"] ?? "";
  }

  Future<void> loadBackground() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      currentBackground = prefs.getString("bg_path") ?? "assets/bg/bg1.jpg";
      useNetwork = prefs.getBool("bg_network") ?? false;
    });
  }

  void autoSave(String value) {
    if (_debounce?.isActive ?? false) _debounce!.cancel();

    _debounce = Timer(const Duration(milliseconds: 800), () async {
      print("📡 Sending PUT request...");
      try {
        var response = await http.put(
          Uri.parse("http://localhost:8001/memo/${widget.item["id"]}"),
          headers: {"Content-Type": "application/json; charset=utf-8"},
          body: jsonEncode({
            "Title": widget.item["Title"],
            "Note": value,
          }),
        );

        if (response.statusCode == 200) {
          print("💾 Auto Saved Successfully");
        } else {
          print("❌ Failed to SAVE: ${response.statusCode}");
        }
      } catch (e) {
        print("🚨 Error saving: $e");
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pop(context, true);
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.pink,
          title: Text(
            widget.item["Title"] ?? "รายละเอียดโน้ต",
            style: const TextStyle(color: Colors.white),
          ),
          centerTitle: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context, true),
          ),
        ),

        body: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTapDown: (details) {
            FocusScope.of(context).requestFocus(focusNode);
            noteCtrl.selection = TextSelection.fromPosition(
              TextPosition(offset: noteCtrl.text.length),
            );
          },

          child: Stack(
            children: [
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: useNetwork
                          ? NetworkImage(currentBackground)
                          : AssetImage(currentBackground) as ImageProvider,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),

              Positioned.fill(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(18),
                  child: TextField(
                    controller: noteCtrl,
                    focusNode: focusNode,
                    maxLines: null,
                    style: const TextStyle(
                      color: Color.fromARGB(255, 0, 0, 0),  
                      fontSize: 22,
                    ),
                    cursorColor: Colors.orange,
                    keyboardType: TextInputType.multiline,
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: "พิมพ์ได้ทุกที่ในหน้าจอ…",
                      hintStyle: TextStyle(color: Colors.white54),
                    ),
                    onChanged: (value) {
                      widget.item["Note"] = value;
                      autoSave(value);
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
