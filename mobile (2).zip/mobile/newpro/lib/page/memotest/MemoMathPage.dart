import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:newpro/page/memotest/AddMemoMathPage.dart';
import 'package:newpro/page/memotest/StatisticPage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MemoMathPage extends StatefulWidget {
  const MemoMathPage({super.key});

  @override
  State<MemoMathPage> createState() => _MemoMathPageState();
}

class _MemoMathPageState extends State<MemoMathPage> {
  List mathList = [];
  bool isLoading = true;
  int currentIndex = 0;

  bool isSelectingMath = false;           
  List<int> selectedMathIds = [];         

  String currentBackground = "";
  bool useNetwork = false;

  @override
  void initState() {
    super.initState();
    loadBackground();
    fetchMath();
  }

  Future<void> loadBackground() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      currentBackground = prefs.getString("bg_path") ?? "";
      useNetwork = prefs.getBool("bg_network") ?? false;
    });
  }

  Future<void> fetchMath() async {
    try {
      var response = await http.get(
        Uri.parse("http://localhost:8001/math"),
        headers: {"Content-Type": "application/json; charset=utf-8"},
      );

      if (response.statusCode == 200) {
        setState(() {
          mathList = jsonDecode(utf8.decode(response.bodyBytes));
          isLoading = false;
        });
      }
    } catch (e) {
      print("GET Error: $e");
    }
  }

  Future<void> deleteMath(int id) async {
    try {
      var response = await http.delete(
        Uri.parse("http://localhost:8001/math/$id"),
        headers: {"Content-Type": "application/json; charset=utf-8"},
      );
    } catch (e) {
      print("DELETE ERROR: $e");
    }
  }

  Future<void> deleteSelectedMath() async {
    for (var id in selectedMathIds) {
      await deleteMath(id);
    }
    fetchMath();
    setState(() {
      selectedMathIds.clear();
      isSelectingMath = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [buildMainPage(), StatisticPage(list: mathList)];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          isSelectingMath ? "เลือก (${selectedMathIds.length})" : "รายรับรายจ่าย",
        ),
        backgroundColor: Colors.green,
        actions: [
          if (!isSelectingMath)
            IconButton(
              icon: const Icon(Icons.check_circle_outline, color: Colors.white),
              onPressed: () {
                setState(() => isSelectingMath = true);
              },
            ),

          if (isSelectingMath)
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.white),
              onPressed: selectedMathIds.isEmpty ? null : deleteSelectedMath,
            ),

          if (isSelectingMath)
            IconButton(
              icon: const Icon(Icons.close, color: Colors.white),
              onPressed: () {
                setState(() {
                  selectedMathIds.clear();
                  isSelectingMath = false;
                });
              },
            ),
        ],
      ),

      body: Container(
        decoration: currentBackground.isEmpty
            ? const BoxDecoration(color: Color.fromARGB(255, 255, 255, 255))
            : BoxDecoration(
                image: DecorationImage(
                  image: useNetwork
                      ? NetworkImage(currentBackground)
                      : AssetImage(currentBackground) as ImageProvider,
                  fit: BoxFit.cover,
                ),
              ),
        child: pages[currentIndex],
      ),

      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.grey.shade900,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.white54,
        currentIndex: currentIndex,
        onTap: (index) => setState(() => currentIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.list), label: "บันทึก"),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: "สถิติ"),
        ],
      ),

      floatingActionButton: currentIndex == 0
          ? FloatingActionButton(
              backgroundColor: Colors.green,
              child: const Icon(Icons.add, size: 30),
              onPressed: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AddMemoMathPage()),
                );
                if (result == true) fetchMath();
              },
            )
          : null,
    );
  }


  Widget buildMainPage() {
    return isLoading
        ? const Center(child: CircularProgressIndicator(color: Colors.green))
        : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: mathList.length,
            itemBuilder: (context, index) {
              var item = mathList[index];
              bool isIncome = item["Title"].toString().startsWith("+");
              bool selected = selectedMathIds.contains(item["id"]);

              return GestureDetector(
                onTap: () {
                  if (isSelectingMath) {
                    setState(() {
                      selected
                          ? selectedMathIds.remove(item["id"])
                          : selectedMathIds.add(item["id"]);
                    });
                  }
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: selected
                        ? Colors.red.withOpacity(0.35)
                        : Colors.black.withOpacity(0.45),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    children: [
                      if (isSelectingMath)
                        Checkbox(
                          value: selected,
                          onChanged: (value) {
                            setState(() {
                              value == true
                                  ? selectedMathIds.add(item["id"])
                                  : selectedMathIds.remove(item["id"]);
                            });
                          },
                        ),
                      Expanded(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(item["Title"],
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 18)),

                            Text("${item["Amount"]} ฿",
                                style: TextStyle(
                                  color: isIncome
                                      ? Colors.greenAccent
                                      : Colors.redAccent,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                )),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
  }
}
