import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StatisticPage extends StatefulWidget {
  final List list;
  const StatisticPage({super.key, required this.list});

  @override
  State<StatisticPage> createState() => _StatisticPageState();
}

class _StatisticPageState extends State<StatisticPage> {
  String filter = "month";
  DateTime? selectedDate;
  List filteredList = [];

  String currentBackground = "";
  bool useNetwork = false;

  @override
  void initState() {
    super.initState();
    loadBackground();
  }

  Future<void> loadBackground() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      currentBackground = prefs.getString("bg_path") ?? "";
      useNetwork = prefs.getBool("bg_network") ?? false;
    });
  }

  @override
  Widget build(BuildContext context) {
    int income = 0;
    int expense = 0;

    for (var i in widget.list) {
      if (i["Title"].toString().startsWith("+")) {
        income += i["Amount"] as int;
      } else {
        expense += i["Amount"] as int;
      }
    }

    int balance = income - expense;

    return Scaffold(
      body: Container(
        decoration: currentBackground.isEmpty
            ? const BoxDecoration(color: Colors.black)
            : BoxDecoration(
                image: DecorationImage(
                  image: useNetwork
                      ? NetworkImage(currentBackground)
                      : AssetImage(currentBackground) as ImageProvider,
                  fit: BoxFit.cover,
                ),
              ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.45),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.green, width: 1),
                ),
                child: ToggleButtons(
                  borderColor: Colors.transparent,
                  selectedBorderColor: Colors.green,
                  selectedColor: Colors.white,
                  color: Colors.white70,
                  fillColor: Colors.green.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(14),
                  isSelected: [
                    filter == "day",
                    filter == "week",
                    filter == "month",
                  ],
                  onPressed: (index) async {
                    setState(() {
                      filter = ["day", "week", "month"][index];
                    });

          
                    if (filter == "day") {
                      DateTime? picked = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2030),
                      );

                      if (picked != null) {
                        setState(() {
                          selectedDate = picked;
                          filteredList = widget.list.where((item) {
                            if (item["date"] == null) return false;
                            DateTime memoDate = DateTime.parse(item["date"]);
                            return memoDate.year == picked.year &&
                                memoDate.month == picked.month &&
                                memoDate.day == picked.day;
                          }).toList();
                        });
                      }
                    }

          
                    if (filter == "week") {
                      DateTime now = DateTime.now();
                      DateTime monday = now.subtract(Duration(days: now.weekday - 1));
                      DateTime sunday = monday.add(const Duration(days: 6));

                      setState(() {
                        filteredList = widget.list.where((item) {
                          if (item["date"] == null) return false;
                          DateTime memoDate = DateTime.parse(item["date"]);
                          return memoDate.isAfter(
                                  monday.subtract(const Duration(days: 1))) &&
                              memoDate.isBefore(
                                  sunday.add(const Duration(days: 1)));
                        }).toList();
                      });
                    }

               
                    if (filter == "month") {
                      DateTime now = DateTime.now();
                      setState(() {
                        filteredList = widget.list.where((item) {
                          if (item["date"] == null) return false;
                          DateTime memoDate = DateTime.parse(item["date"]);
                          return memoDate.year == now.year &&
                              memoDate.month == now.month;
                        }).toList();
                      });
                    }
                  },
                  children: const [
                    Padding(padding: EdgeInsets.symmetric(horizontal: 18, vertical: 10), child: Text("วัน")),
                    Padding(padding: EdgeInsets.symmetric(horizontal: 18, vertical: 10), child: Text("สัปดาห์")),
                    Padding(padding: EdgeInsets.symmetric(horizontal: 18, vertical: 10), child: Text("เดือน")),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              infoCard("รายรับทั้งหมด", "+ $income ฿", Colors.greenAccent),
              const SizedBox(height: 16),
              infoCard("รายจ่ายทั้งหมด", "- $expense ฿", Colors.redAccent),
              const SizedBox(height: 16),
              infoCard("ยอดคงเหลือ", "$balance ฿", Colors.orangeAccent),

              const SizedBox(height: 20),

              if (filter == "day" || filter == "week" || filter == "month")
                Expanded(
                  child: filteredList.isEmpty
                      ? const Center(
                          child: Text(
                            "ไม่มีข้อมูลในช่วงนี้",
                            style: TextStyle(color: Colors.white70, fontSize: 18),
                          ),
                        )
                      : ListView.builder(
                          itemCount: filteredList.length,
                          itemBuilder: (context, index) {
                            var item = filteredList[index];
                            bool isIncome = item["Title"].toString().startsWith("+");

                            return Card(
                              color: Colors.black.withOpacity(0.65),
                              child: ListTile(
                                leading: Icon(
                                  isIncome ? Icons.arrow_upward : Icons.arrow_downward,
                                  color: isIncome ? Colors.green : Colors.redAccent,
                                ),
                                title: Text(item["Title"],
                                    style: const TextStyle(color: Colors.white)),
                                subtitle: Text(item["date"],
                                    style: const TextStyle(color: Colors.white54)),
                                trailing: Text(
                                  "${item["Amount"]} ฿",
                                  style: TextStyle(
                                    color: isIncome ? Colors.green : Colors.redAccent,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget infoCard(String title, String value, Color color) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.45),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(color: Colors.white70, fontSize: 16)),
          const SizedBox(height: 8),
          Text(value,
              style: TextStyle(
                  color: color, fontSize: 26, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
