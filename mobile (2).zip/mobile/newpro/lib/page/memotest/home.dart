import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:newpro/page/memotest/AddMemoPage.dart';
import 'package:newpro/page/memotest/MemoDePage.dart';
import 'package:newpro/page/memotest/MemoMathPage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MemoHomePage extends StatefulWidget {
  const MemoHomePage({super.key});

  @override
  State<MemoHomePage> createState() => _MemoHomePageState();
}

class _MemoHomePageState extends State<MemoHomePage> {
  List memos = [];
  bool isLoading = true;

  bool isSelecting = false;
  List<int> selectedIds = [];

  String? currentBackground;  
  bool useNetwork = false;

  @override
  void initState() {
    super.initState();
    loadBackground();
    fetchMemos();
  }

  Future<void> loadBackground() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      currentBackground = prefs.getString("bg_path"); 
      useNetwork = prefs.getBool("bg_network") ?? false;
    });
  }

  Future<void> saveBackground(String path, bool isNetwork) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString("bg_path", path);
    await prefs.setBool("bg_network", isNetwork);
  }

  Future<void> fetchMemos() async {
    try {
      var response = await http.get(
        Uri.parse("http://localhost:8001/memo"),
        headers: {"Content-Type": "application/json; charset=utf-8"},
      );

      if (response.statusCode == 200) {
        setState(() {
          memos = jsonDecode(utf8.decode(response.bodyBytes));
          isLoading = false;
        });
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  Future<void> deleteMemo(int id) async {
    try {
      var response = await http.delete(
        Uri.parse("http://localhost:8001/memo/$id"),
        headers: {"Content-Type": "application/json; charset=utf-8"},
      );
      if (response.statusCode == 200) fetchMemos();
    } catch (e) {
      print("DELETE ERROR: $e");
    }
  }

  Future<void> deleteSelected() async {
    for (var id in selectedIds) {
      await deleteMemo(id);
    }
    setState(() {
      selectedIds.clear();
      isSelecting = false;
    });
  }

  void chooseBackground() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black87,
        title: const Text("เลือกพื้นหลัง", style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            buildBgAsset("assets/1.jpg"),
            buildBgAsset("assets/3.jpg"),
            buildBgAsset("assets/4.jpg"),
            buildBgAsset("assets/7.jpg"),
            buildBgAsset("assets/5.jpg"),

            const SizedBox(height: 15),

            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                minimumSize: const Size(double.infinity, 45),
              ),
              icon: const Icon(Icons.delete_forever, color: Colors.white),
              label: const Text("ลบพื้นหลัง / Reset", style: TextStyle(color: Colors.white)),
              onPressed: () async {
                SharedPreferences prefs = await SharedPreferences.getInstance();
                await prefs.remove("bg_path");
                await prefs.remove("bg_network");

                setState(() {
                  currentBackground = null; 
                  useNetwork = false;
                });

                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget buildBgAsset(String path) {
    return GestureDetector(
      onTap: () async {
        setState(() {
          currentBackground = path;
          useNetwork = false;
        });
        await saveBackground(path, false);
        Navigator.pop(context);
      },
      child: buildPreview(AssetImage(path)),
    );
  }

  Widget buildBgNetwork(String url) {
    return GestureDetector(
      onTap: () async {
        setState(() {
          currentBackground = url;
          useNetwork = true;
        });
        await saveBackground(url, true);
        Navigator.pop(context);
      },
      child: buildPreview(NetworkImage(url)),
    );
  }

  Widget buildPreview(ImageProvider img) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      height: 70,
      decoration: BoxDecoration(
        image: DecorationImage(image: img, fit: BoxFit.cover),
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        backgroundColor: const Color.fromARGB(255, 113, 113, 113),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Color.fromARGB(255, 215, 59, 124)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Icon(Icons.menu_book, size: 60, color: Colors.white),
                  SizedBox(height: 8),
                  Text("MY MEMO",
                      style: TextStyle(color: Colors.white, fontSize: 18)),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.attach_money, color: Colors.greenAccent),
              title: const Text("บันทึกรายรับรายจ่าย", style: TextStyle(color: Colors.white)),
              onTap: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const MemoMathPage())),
            ),
          ],
        ),
      ),

      appBar: AppBar(
        backgroundColor: Colors.pink.withOpacity(0.85),
        surfaceTintColor: Colors.transparent,
        title: Text(isSelecting ? "เลือกโน้ต (${selectedIds.length})" : "โน้ต",
          style: const TextStyle(color: Colors.white),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.wallpaper, color: Colors.white),
              onPressed: chooseBackground),

          if (!isSelecting)
            IconButton(
              icon: const Icon(CupertinoIcons.check_mark_circled, color: Colors.white),
              onPressed: () => setState(() => isSelecting = true),
            ),

          if (isSelecting)
            IconButton(
              icon: const Icon(CupertinoIcons.delete, color: Colors.white),
              onPressed: selectedIds.isEmpty ? null : deleteSelected,
            ),

          if (isSelecting)
            IconButton(
              icon: const Icon(CupertinoIcons.xmark_circle_fill, color: Colors.white),
              onPressed: () {
                setState(() {
                  isSelecting = false;
                  selectedIds.clear();
                });
              },
            ),
        ],
      ),

      body: Container(
        decoration: BoxDecoration(
          color: currentBackground == null ? const Color.fromARGB(255, 255, 255, 255) : null,
          image: currentBackground != null
              ? DecorationImage(
                  image: useNetwork
                      ? NetworkImage(currentBackground!)
                      : AssetImage(currentBackground!) as ImageProvider,
                  fit: BoxFit.cover,
                )
              : null,
        ),
        child: isLoading
            ? const Center(child: CircularProgressIndicator(color: Color.fromARGB(255, 43, 208, 65)))
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: memos.length,
                itemBuilder: (context, index) {
                  var item = memos[index];
                  bool selected = selectedIds.contains(item["id"]);

                  return GestureDetector(
                    onTap: () {
                      if (isSelecting) {
                        setState(() {
                          selected
                              ? selectedIds.remove(item["id"])
                              : selectedIds.add(item["id"]);
                        });
                      } else {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => MemoDetailPage(item: item),
                          ),
                        );
                      }
                    },
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 14),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: selected
                            ? Colors.red.withOpacity(0.3)
                            : Colors.black.withOpacity(0.5),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          if (isSelecting)
                            Checkbox(
                              value: selected,
                              onChanged: (value) {
                                setState(() {
                                  value == true
                                      ? selectedIds.add(item["id"])
                                      : selectedIds.remove(item["id"]);
                                });
                              },
                            ),
                          Expanded(
                            child: ListTile(
                              title: Text(item["Title"] ?? "",
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                              subtitle: Text(
                                (item["Note"] ?? "").split("\n").first,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: Colors.white70, fontSize: 13),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),

      floatingActionButton: !isSelecting
          ? FloatingActionButton(
              backgroundColor: const Color.fromARGB(255, 217, 45, 131),
              child: const Icon(Icons.add, size: 32),
              onPressed: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AddMemoPage()),
                );
                if (result != null) fetchMemos();
              },
            )
          : FloatingActionButton.extended(
              backgroundColor: Colors.red,
              icon: const Icon(CupertinoIcons.delete_solid, size: 26, color: Colors.white),
              label: Text("ลบ (${selectedIds.length})",
                  style: const TextStyle(color: Colors.white, fontSize: 18)),
              onPressed: selectedIds.isEmpty ? null : () async {
                await deleteSelected();
              },
            ),
    );
  }
}